package com.social.project.util;
import com.social.project.util.LikeCountFormatter;



public class LikeCountFormatter {

    public static String format(long count) {

        if (count < 1_000) {
            return String.valueOf(count);
        }

        if (count < 1_000_000) {
            return String.format("%.1fK", count / 1_000.0)
                    .replace(".0K", "K");
        }

        if (count < 1_000_000_000) {
            return String.format("%.1fM", count / 1_000_000.0)
                    .replace(".0M", "M");
        }

        return String.format("%.1fB", count / 1_000_000_000.0)
                .replace(".0B", "B");
    }
}
