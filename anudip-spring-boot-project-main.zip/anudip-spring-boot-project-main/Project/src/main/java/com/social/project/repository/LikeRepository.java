package com.social.project.repository;

import com.social.project.model.Like;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LikeRepository extends JpaRepository<Like, Long> {

    long countByPostId(Long postId);

    boolean existsByPostIdAndUsername(Long postId, String username);
}
